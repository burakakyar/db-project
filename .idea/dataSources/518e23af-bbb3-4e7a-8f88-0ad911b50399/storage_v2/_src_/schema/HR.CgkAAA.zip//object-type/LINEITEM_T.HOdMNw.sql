create TYPE LINEITEM_T 
    AS OBJECT 
    ( 
        SYS_XDBPD$ XDB$RAW_LIST_T , 
        ITEMNUMBER NUMBER (38) , 
        DESCRIPTION VARCHAR2 (256) , 
        PART PART_T 
    ) NOT FINAL 
;
/

